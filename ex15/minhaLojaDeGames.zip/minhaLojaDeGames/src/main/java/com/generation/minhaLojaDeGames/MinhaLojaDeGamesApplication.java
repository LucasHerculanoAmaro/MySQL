package com.generation.minhaLojaDeGames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhaLojaDeGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhaLojaDeGamesApplication.class, args);
	}

}
